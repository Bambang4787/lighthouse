---
name: Feature request
about: Suggest an idea to us!

---

<!-- Before creating an feature request please make sure you are using the latest version. -->

<!-- If this is a new audit please review the audit doc https://github.com/GoogleChrome/lighthouse/blob/master/docs/new-audits.md -->

**Feature request summary**
<!-- Describe what you want to be added -->
<!-- Are you willing to work on this yourself? -->


**What is the motivation or use case for changing this?**


**How is this beneficial to Lighthouse?**

